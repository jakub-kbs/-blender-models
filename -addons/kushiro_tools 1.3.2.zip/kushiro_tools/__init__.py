# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
# Created by Kushiro
import bpy


from bpy.props import (
        FloatProperty,
        IntProperty,
        BoolProperty,
        EnumProperty,
        )


#from . import helper

import importlib

# from .connect_face import connect_face
# from .cut_corner import cut_corner
# from .quad_swords import quad_swords
# from .quick_bridge import quick_bridge
# from .select_sim import select_sim
# from .surface_inflate import surface_inflate
# from .visual_axis import visual_axis

# from .connect_face import connect_face

from . import attach_align
from . import connect_face
from . import cut_corner
from . import quad_swords
from . import quick_bridge
from . import select_sim
from . import surface_inflate
from . import soft_bevel
from . import visual_axis

# from .connect_face.connect_face import CONNECTFACE_OT_operator
# from .cut_corner.cut_corner import CutCornerOperator
# from .quad_swords.quad_swords import QuadSwordsOperator
# from .quick_bridge.quick_bridge import QuickBridgeOperator
# from .select_sim.select_sim import SelectSimOperator
# from .surface_inflate.surface_inflate import SurfaceInflateOperator
# from .visual_axis.visual_axis import VisualAxisOperator




bl_info = {
    "name": "Kushiro Tools",
    "description": "Kushiro Tools",
    "author": "Kushiro",
    "version": (1, 3, 2),
    "blender": (2, 83, 0),
    "location": "View3D > Edit > Context Menu (right click)",
    "category": "Mesh",
}


class VIEW3D_MT_my_addon_submenu(bpy.types.Menu):
    bl_label = "Kushiro Tools"

    def draw(self, context):
        layout = self.layout
        layout.operator('mesh.attach_align_operator')
        layout.operator('mesh.connectface_operator')
        layout.operator('mesh.cut_corner_operator')
        layout.operator('mesh.quad_swords_operator')
        layout.operator('mesh.quick_bridge_operator')
        layout.operator('mesh.select_sim_operator')
        layout.operator('mesh.surface_inflate_operator')
        layout.operator('mesh.soft_bevel_operator')
        layout.operator('mesh.visual_axis_operator')



def menu_func(self, context):
    layout = self.layout
    layout.menu("VIEW3D_MT_my_addon_submenu")

# def menu_func(self, context):
#     self.layout.operator_context = "INVOKE_DEFAULT";    
#     self.layout.operator(surface_inflate.SurfaceInflateOperator.bl_idname)


def register():
    # bpy.utils.register_class(connect_face.connect_face.CONNECTFACE_OT_operator)
    bpy.utils.register_class(attach_align.AttachAlignOperator)
    bpy.utils.register_class(attach_align.AttachAlignSlideOperator)

    bpy.utils.register_class(connect_face.CONNECTFACE_OT_operator)
    bpy.utils.register_class(cut_corner.CutCornerOperator)
    bpy.utils.register_class(quad_swords.QuadSwordsOperator)
    bpy.utils.register_class(quick_bridge.QuickBridgeOperator)
    bpy.utils.register_class(select_sim.SelectSimOperator)
    bpy.utils.register_class(soft_bevel.SoftBevelOperator)
    bpy.utils.register_class(surface_inflate.SurfaceInflateOperator)
    bpy.utils.register_class(visual_axis.VisualAxisOperator)

    # connect_face.register()
    # cut_corner.register()
    # quad_swords.register()
    # quick_bridge.register()
    # select_sim.register()
    # surface_inflate.register()
    # visual_axis.register()
    

    bpy.utils.register_class(VIEW3D_MT_my_addon_submenu)    
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.append(menu_func)
    
    # bpy.types.VIEW3D_MT_object_context_menu.append(menu_func)

# def register():    
#     importlib.reload(surface_inflate)   
#     bpy.utils.register_class(surface_inflate.SurfaceInflateOperator)
#     bpy.types.VIEW3D_MT_edit_mesh_context_menu.append(menu_func)


def unregister():
    bpy.utils.unregister_class(attach_align.AttachAlignSlideOperator)
    bpy.utils.unregister_class(connect_face.CONNECTFACE_OT_operator)
    bpy.utils.unregister_class(cut_corner.CutCornerOperator)
    bpy.utils.unregister_class(quad_swords.QuadSwordsOperator)
    bpy.utils.unregister_class(quick_bridge.QuickBridgeOperator)
    bpy.utils.unregister_class(select_sim.SelectSimOperator)
    bpy.utils.unregister_class(surface_inflate.SurfaceInflateOperator)
    bpy.utils.unregister_class(soft_bevel.SoftBevelOperator)
    bpy.utils.unregister_class(visual_axis.VisualAxisOperator)
        
    
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.remove(menu_func)
    # bpy.utils.unregister_class(surface_inflate.SurfaceInflateOperator)



    
if __name__ == "__main__":    
    register()



def test():    
    #importlib.reload(helper)    
    
    try:
        unregister()
    except :
        pass
    
    try:
        register()
    except :
        pass
    
    print('test loaded')


