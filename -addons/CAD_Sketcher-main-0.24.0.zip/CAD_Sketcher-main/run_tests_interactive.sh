blender --addons CAD_Sketcher --python ./testing/__init__.py -- --interactive --log_level=INFO
