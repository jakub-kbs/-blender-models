::: CAD_Sketcher.class_defines.SketcherProps
    selection:
      members: true
    rendering:
      show_root_heading: true

::: CAD_Sketcher.class_defines.SlvsEntities
    selection:
      members: true
    rendering:
      show_root_heading: true

::: CAD_Sketcher.class_defines.SlvsConstraints
    selection:
      members: true
    rendering:
      show_root_heading: true
